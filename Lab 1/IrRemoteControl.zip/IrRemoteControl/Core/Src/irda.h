/*
 * irda.h
 *
 *  Created on: Nov 1, 2024
 *      Author: trung
 */

#ifndef SRC_IRDA_H_
#define SRC_IRDA_H_

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx_hal.h"

void IrDecode();
void IrGetBitTime();

#endif /* SRC_IRDA_H_ */
